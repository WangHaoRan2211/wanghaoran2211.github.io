from tkinter import *
from tkinter.ttk import *
from tkinter.filedialog import *
from loader import *
from os.path import *


def open_file():
    a=askopenfile(defaultextension='.txt',filetypes=[('插件文件','*.zip'),('Edgeless插件文件','*.7z'),('所有文件','*.*')],title='打开文件')
    ent1.configure(text=a.name)



win=Tk()
win.title('插件加载器')
#win.resizable(False,False)
ent1=Label(win)
ent1.grid(row=0,column=0)
but1=Button(win,text='浏览',command=open_file)
but1.grid(row=0,column=1)
but2=Button(win,text='加载',command=lambda:load_extension(ent1['text'],'X:\\PESoftwares\\Extensions',split(splitext(ent1['text'])[0])[1]))
but2.grid(row=1,column=0)
but3=Button(win,text='退出',command=win.quit)
but3.grid(row=1,column=1)
but4=Button(win,text='作为Edgeless插件加载(测试)',command=lambda:load_edgeless_extension(ent1['text']))
but4.grid(row=2,column=0)
win.mainloop()
