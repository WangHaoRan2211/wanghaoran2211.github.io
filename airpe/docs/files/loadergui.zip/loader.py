from os import *
from zipfile import *
from py7zr import *
from glob import glob
import shutil

def load_extension(file_path,extra_path,name):
    #print(name)
    # Extract file

    extension_file = ZipFile(file_path)
    for file in extension_file.namelist():
        extension_file.extract(file,extra_path)

    # Load extension

    pecmd('LOAD '+extra_path+'\\'+name+'\\loadsoft.ini')



def remove_file(old_path, new_path):
    filelist = listdir(old_path)      
    for file in filelist:
        src = path.join(old_path, file)
        dst = path.join(new_path, file)
        shutil.move(src, dst)




def load_edgeless_extension(file_path):
    if not path.exists('X:\\Program Files\\Edgeless'):
        mkdir('X:\\Program Files\\Edgeless')
    if not path.exists('X:\\Program Files\\Tmp'):
        mkdir('X:\\Program Files\\Tmp')
    z7=SevenZipFile(file_path, 'r')
    z7.extractall(path='X:\\Program Files\\Tmp')
    z7.close()
    wcssp=glob('X:\\Program Files\\Tmp\\*.wcs')
    cmdsp=glob('X:\\Program Files\\Tmp\\*.cmd')
    remove_file('X:\\Program Files\\Tmp','X:\\Program Files\\Edgeless')
    wcssp1=[]
    cmdsp1=[]
    for i in range(1,len(wcssp)):
        wcssp1.append(basename(wcssp[i]))
    for j in range(1,len(cmdsp)):
        cmdsp1.append(basename(cmdsp[j]))
    for index in range(1,len(wcssp1)):
        pecmd('LOAD "%ProgramFiles%\\Edgeless\\'+wcssp1[index])
    for jndex in range(1,len(wcssp1)):
        pecmd('LOAD "%ProgramFiles%\\Edgeless\\'+cmdsp1[jndex])
    remove('X:\\Program Files\\Tmp')



def pecmd(command):
    system('pecmd.exe ' + command)
